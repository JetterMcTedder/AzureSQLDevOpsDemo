﻿CREATE TABLE [dbo].[ExampleTable]
(
	[Id] INT NOT NULL PRIMARY KEY,
	[Amount] DECIMAL(13, 3) NOT NULL
)
