﻿EXEC tSQLt.RunAll;
/*
EXEC tSQLt.Run 'dbo_CalculateDiscountTests';
--*/
